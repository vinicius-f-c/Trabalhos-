let produtos = [];
let historico = [];

class Produto {

  constructor(nome, preco) {
    this.nome = nome;
    this.preco = preco;
    this.saldo = 0;
  }

}

function cadastrarProduto() {

  let nome = document.getElementById("nome-produto").value;

  let preco = Number(
    document.getElementById("preco-produto").value
  );

  if(nome === "" || preco <= 0) {

    mostrarMensagem("Preencha os campos corretamente");

    return;
  }

  let produto = new Produto(nome, preco);

  produtos.push(produto);

  atualizarSelects();

  adicionarHistorico(
    `Produto ${nome} cadastrado`
  );

  mostrarMensagem("Produto cadastrado com sucesso!");

  document.getElementById("nome-produto").value = "";

  document.getElementById("preco-produto").value = "";

}

function atualizarSelects() {

  let selectEntrada =
    document.getElementById("produto-entrada");

  let selectAjuste =
    document.getElementById("produto-ajuste");

  let selectSaida =
    document.getElementById("produto-saida");

  selectEntrada.innerHTML =
    `<option value="">Selecione um produto</option>`;

  selectAjuste.innerHTML =
    `<option value="">Selecione um produto</option>`;

  selectSaida.innerHTML =
    `<option value="">Selecione um produto</option>`;

  produtos.forEach((produto, index) => {

    let option =
      `<option value="${index}">
        ${produto.nome}
      </option>`;

    selectEntrada.innerHTML += option;

    selectAjuste.innerHTML += option;

    selectSaida.innerHTML += option;

  });

}

function darEntrada() {

  let index =
    document.getElementById("produto-entrada").value;

  let quantidade = Number(
    document.querySelectorAll(".card input")[2].value
  );

  if(index === "" || quantidade <= 0) {

    mostrarMensagem("Preencha corretamente");

    return;
  }

  produtos[index].saldo += quantidade;

  adicionarHistorico(
    `Entrada de ${quantidade} unidades de ${produtos[index].nome}`
  );

  atualizarTabela();

  mostrarMensagem("Entrada realizada com sucesso!");

  document.querySelectorAll(".card input")[2].value = "";

}

function ajustarEstoque() {

  let index =
    document.getElementById("produto-ajuste").value;

  let quantidade = Number(
    document.querySelectorAll(".card input")[3].value
  );

  if(index === "" || quantidade === 0) {

    mostrarMensagem("Preencha corretamente");

    return;
  }

  produtos[index].saldo += quantidade;

  adicionarHistorico(
    `Ajuste de ${quantidade} unidades em ${produtos[index].nome}`
  );

  atualizarTabela();

  mostrarMensagem("Ajuste realizado com sucesso!");

  document.querySelectorAll(".card input")[3].value = "";

}

function darSaida() {

  let index =
    document.getElementById("produto-saida").value;

  let quantidade = Number(
    document.querySelectorAll(".card input")[4].value
  );

  if(index === "" || quantidade <= 0) {

    mostrarMensagem("Preencha corretamente");

    return;
  }

  produtos[index].saldo -= quantidade;

  adicionarHistorico(
    `Saída de ${quantidade} unidades de ${produtos[index].nome}`
  );

  atualizarTabela();

  mostrarMensagem("Saída realizada com sucesso!");

  document.querySelectorAll(".card input")[4].value = "";

}

function atualizarTabela() {

  let tabela =
    document.getElementById("tabela-produtos");

  tabela.innerHTML = "";

  produtos.forEach(produto => {

    let status =
      produto.saldo <= 5
      ? '<span class="status-baixo">ESTOQUE BAIXO</span>'
      : '<span class="status-ok">OK</span>';

    tabela.innerHTML += `
      <tr>

        <td>${produto.nome}</td>

        <td>${produto.saldo}</td>

        <td>R$ ${produto.preco.toFixed(2)}</td>

        <td>${status}</td>

      </tr>
    `;

  });

}

function adicionarHistorico(texto) {

  historico.unshift(texto);

  let divHistorico =
    document.getElementById("historico");

  divHistorico.innerHTML = "";

  historico.forEach(item => {

    divHistorico.innerHTML += `
      <div class="item-historico">
        ${item}
      </div>
    `;

  });

}

function mostrarMensagem(texto) {

  let mensagem =
    document.getElementById("mensagem");

  mensagem.textContent = texto;

  mensagem.classList.add("mostrar");

  setTimeout(() => {

    mensagem.classList.remove("mostrar");

  }, 2500);

}

document.querySelectorAll("button")[0]
  .addEventListener("click", cadastrarProduto);

document.querySelectorAll("button")[1]
  .addEventListener("click", darEntrada);

document.querySelectorAll("button")[2]
  .addEventListener("click", ajustarEstoque);

document.querySelectorAll("button")[3]
  .addEventListener("click", darSaida);